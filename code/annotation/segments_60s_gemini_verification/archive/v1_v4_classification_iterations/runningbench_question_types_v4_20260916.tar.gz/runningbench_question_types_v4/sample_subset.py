# -*- coding: utf-8 -*-
"""按题型分层抽取 1/N 子集。
设计: (type_sub_category x arity) 比例分配 + 最大余数法凑齐总数 + 每个 60s 片段最多取 1 题。
比例分配保证整体分数无偏, 无需加权; 片段去重保证子集的视频多样性不塌。"""
import json, random, collections, sys, os

SRC=os.environ.get('RB_TYPED','segments_60s_typed.jsonl')
FRAC=int(os.environ.get('RB_FRAC','10'))          # 抽 1/FRAC
SEED=int(os.environ.get('RB_SEED','20260916'))
VCAP=int(os.environ.get('RB_VIDEO_CAP','5'))     # 每视频题数上限; 实测 5 使设计效应最低
OUT=os.environ.get('RB_OUT','segments_60s_subset.jsonl')

rows=[json.loads(l) for l in open(SRC)]
target=round(len(rows)/FRAC)

strata=collections.defaultdict(list)
for r in rows: strata[(r['type_sub_category'],r['arity'])].append(r)

# 最大余数法: 保证各层比例误差最小且总数恰为 target
exact={k:len(v)*target/len(rows) for k,v in strata.items()}
quota={k:int(v) for k,v in exact.items()}
rem=sorted(strata, key=lambda k:-(exact[k]-quota[k]))
for k in rem[:target-sum(quota.values())]: quota[k]+=1

rng=random.Random(SEED)
used_seg=set(); per_vid=collections.Counter(); picked=[]
for k in sorted(strata, key=lambda k:-len(strata[k])):
    pool=strata[k][:]; rng.shuffle(pool); got=0
    # 依次放宽: 守视频上限+片段不重复 -> 放开视频上限 -> 放开片段去重
    for vlim, segdedup in ((VCAP,True),(10**9,True),(10**9,False)):
        if got>=quota[k]: break
        for r in pool:
            if got>=quota[k]: break
            if r in picked: continue
            seg=(r['video'],tuple(r['span_sec']))
            if segdedup and seg in used_seg: continue
            if per_vid[r['video']]>=vlim: continue
            used_seg.add(seg); per_vid[r['video']]+=1; picked.append(r); got+=1

# 保证每个视频至少 1 题: 同层交换, 配额与比例完全不变
if os.environ.get('RB_COVER_ALL','1')=='1':
    pick_ids={r['id'] for r in picked}
    by_stratum=collections.defaultdict(list)
    for r in picked: by_stratum[(r['type_sub_category'],r['arity'])].append(r)
    covered={r['video'] for r in picked}
    all_vids={r['video'] for r in rows}
    by_vid=collections.defaultdict(list)
    for r in rows: by_vid[r['video']].append(r)
    for v in sorted(all_vids-covered):
        cand=sorted(by_vid[v], key=lambda r:r['id'])
        done=False
        for r in cand:                       # 找一个能换进来的
            k=(r['type_sub_category'],r['arity'])
            # 从同层里挑一个所属视频题数最多的换出去
            cnt=collections.Counter(x['video'] for x in picked)
            outs=sorted(by_stratum[k], key=lambda x:-cnt[x['video']])
            for o in outs:
                if cnt[o['video']]<=1: continue   # 别把别人唯一的一题换掉
                picked.remove(o); by_stratum[k].remove(o)
                picked.append(r); by_stratum[k].append(r)
                pick_ids.discard(o['id']); pick_ids.add(r['id'])
                done=True; break
            if done: break
        if not done: print(f'  [warn] 视频 {v} 无法在不破坏配额的前提下纳入')

picked.sort(key=lambda r:(r['video'],r['span_sec'],r['id']))
with open(OUT,'w') as f:
    for r in picked: f.write(json.dumps(r,ensure_ascii=False)+'\n')
print(f'{len(picked)} 题 -> {OUT}  (目标 {target}, 种子 {SEED})')
