# RunningBench 60s 片段题型分类 v4

6770 题 / 1400 个 60s 片段 / 126 视频的单标签题型分类，含分类规范、标注产物、规则分类器与人工验收基准。

## 先读

**`question_type_spec.md`** —— 分类规范正文。分类表、判定优先级、三条关键判据、被否决方案的原因、精度边界。

## 目录

```
question_type_spec.md              分类规范 (主文档)
distribution.csv                   各类分布速查: 题数/占比/覆盖视频/scoped占比/多选占比
classify_question_types.py         规则分类器
data/segments_60s_typed.jsonl      6770 题原文 + 3 个新字段  ← 交付主体
data/question_types_full_auto.jsonl  分类器原始输出, 含 distractor_presence 中间量
gold/question_types_relabeled_46.jsonl       46 题人工标注 (验收基准)
gold/question_types_original6_relabeled.jsonl 最初 6 条草案标注的重标结果
```

## 新增字段

`segments_60s_typed.jsonl` 在原题基础上加三个字段，原有字段逐条校验未改动：

- `type_category` / `type_sub_category` —— 单标签题型，9 个 sub_category
- `temporal_scope` —— `static`（60s 内任一时刻单帧可判，76.5%）/ `scoped`（须定位时间窗，23.5%）

## 抽子集

```bash
RB_FRAC=10 python3 sample_subset.py          # 1/10 = 677 题 -> segments_60s_subset.jsonl
```

设计：`(type_sub_category x arity)` 按比例分配 + 最大余数法凑齐总数 + **每个 60s 片段最多取 1 题** + **每个视频最多取 5 题**（`RB_VIDEO_CAP`）。
比例分配使整体分数无偏、无需加权；片段去重与视频上限压低簇内相关，使有效样本量不塌。

**每视频上限取 5 是实测结果**，在同一比例分配下对比（题数与比例偏差全部相同）：

| 每视频上限 | 视频覆盖 | 设计效应 | 有效样本量 |
|---|---|---|---|
| 3 | 126 | 1.21 | 560 |
| **5** | **126** | **1.11** | **612** |
| 7 | 124 | 1.14 | 596 |
| 10 | 120 | 1.23 | 551 |
| 无上限 | 120 | 1.33 | 510 |

上限太松则少数大视频吃掉过多配额，太紧则被迫从题量小的视频里硬凑，两头都抬高设计效应。

产物 `data/segments_60s_subset.jsonl`（677 题）实测：各类比例偏差 ≤0.07 个百分点，arity 精确保持，覆盖 126/126 视频、677 个不同片段、无片段复用，每视频 1~10 题（中位 5），设计效应 1.11。

### 子集的分类型报表口径

677 题撑不起 9 类各自的分数。按比例抽样后各类的 95% 置信区间半宽（p=0.5 最坏情况）：

| 报表桶 | n | ± |
|---|---|---|
| Static Detail QA | 256 | 6.1% |
| Ego-relative Spatial Relation | 131 | 8.6% |
| Trajectory-grounded QA | 89 | 10.4% |
| Ego-motion Recognition | 65 | 12.2% |
| Temporally-scoped Object QA | 60 | 12.7% |
| **长尾合并桶**（Actor + Scene + Temporal Grounding + Event Sequencing） | 76 | 11.2% |
| 整体 | 677 | 3.8% |

**只报上面 6 个桶。** 单独拆开报长尾那 4 类时 n=14~29、误差 ±18~26%，比随机噪声大不了多少。要给这 4 类单独出分数，只能回到全量 6770 题跑。

## 复现

```bash
RB_SRC=/path/to/segments_60s.jsonl RB_OUT=out.jsonl python3 classify_question_types.py
```

无第三方依赖，纯标准库。分类器与 46 题人工标注一致率 **91%**。

## 使用前必读的三条限制

1. **Ego-motion Recognition 的 9.5% 是全量最弱的数字** —— 人工样本只确认了 1 例。要依赖 Ego-motion Recognition / Trajectory-grounded 这条边界，需先对 A 类做针对性抽样复核；否则只报大类 Ego-motion and trajectory（22.7%）。
2. **多选评分方式须先定死** —— 类型与 arity 强相关（Spatial Relation 71% 多选，Trajectory 93% 单选），部分对怎么算分会系统性抬高或压低特定类别。
3. **Static Detail QA 仍占 37.9%**，内部缺区分度；`temporal_scope` 只从中移走了 8.8 个百分点。

详见 `question_type_spec.md` 第 7 节。
